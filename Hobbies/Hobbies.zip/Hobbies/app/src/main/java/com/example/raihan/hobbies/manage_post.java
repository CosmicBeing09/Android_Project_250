package com.example.raihan.hobbies;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class manage_post extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_manage_post);
    }
}
