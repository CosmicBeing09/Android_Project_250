package com.example.raihan.hobbies;

public interface OnItemClickListener {

    void onItemClick(int position);
    void OnMessageClick(int position);
    void OnDeleteClick(int position);
}
